var code = {
    // Returns "Hello World!"
    helloWorld: function() {
        return "Hello World!";
    },

    // Take a single-spaced <sentence>, and capitalize every <n>th word starting with <offset>.
    capitalizeEveryNthWord: function(sentence, offset, n) {
      var words = sentence.split(" ");
      var firstPart = [];
      var lastPart = words;

      if(offset > 0) {
        firstPart = words.slice(0, offset);
        lastPart = words.slice(offset, words.length);
      }

      for (x=0; x < lastPart.length; x++) {
        if(x % n === 0) {
          lastPart[x] = lastPart[x].charAt(0).toUpperCase().concat(lastPart[x].substring(1));
        }
      }

      return firstPart.concat(lastPart).join(' ');
    },

    // Determine if a number is prime
    isPrime: function(n) {
      var isItPrime = true;

      if (n <= 0) {
        isItPrime = false;
      } else if (n === 1) {
        isItPrime = true;
      } else {
        for(x=2; x < n; x++) {
          if (n % x === 0) {
            isItPrime = false;
          }
        }
      }

      return isItPrime;
    },

    // Calculate the golden ratio.
    // Given two numbers a and b with a > b > 0, the ratio is b / a.
    // Let c = a + b, then the ratio c / b is closer to the golden ratio.
    // Let d = b + c, then the ratio d / c is closer to the golden ratio.
    // Let e = c + d, then the ratio e / d is closer to the golden ratio.
    // If you continue this process, the result will trend towards the golden ratio.
    goldenRatio: function(a, b) {
      var ratio = b / a;

      function getNewRatio(x, y) {
      var newRatio = x / y;
      returnRatio = 0;

        if ((newRatio > 1.61800) && (newRatio < 1.61806)) {
          returnRatio = newRatio;
        } else {
          getNewRatio((x + y), x);
        }
          return returnRatio;
      }

      if ((ratio > 1.61800) && (ratio < 1.61806)) {
        return ratio;
      } else {
        var goldenRatio = getNewRatio((a + b), b);
        return goldenRatio;
      }
    },

    // Give the nth Fibonacci number
    // Starting with 0, 1, 1, 2, ... a Fibonacci number is the sum of the previous two.
    fibonacci: function(n) {
      if (n <= 2) {
        return 1;
      } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
      }
    },

    // Give the square root of a number
    // Using a binary search algorithm, search for the square root of a given number.
    // Do not use the built-in square root function.
    squareRoot: function(n) {
      if (n <=1 ) { return n; }

      var min = 1;
      var max = n;

      while (max - min > 0.00001) {
        var mid = min + (max - min) / 2;
        if (mid * mid - n > 0.00001) {
          max = mid;
        } else {
          min = mid;
        }
      }

      return Math.round(min * 10000)/10000;
};
module.exports = code;
