using System;

class Code {
    // Returns "Hello World!"
    public static string HelloWorld() {
        throw new Exception("Not Implemented");
    }

    // Take a single-spaced <sentence>, and capitalize every <n>th word starting with <offset>.
	public static string CapitalizeEveryNthWord(string sentence, int offset, int n) {
        throw new Exception("Not Implemented");
	}
    
    // Determine if a number is prime
    public static bool IsPrime(int n) {
        throw new Exception("Not Implemented");
    }
    
    // Calculate the golden ratio.
    // Given two numbers a and b with a > b > 0, the ratio is b / a.
    // Let c = a + b, then the ratio c / b is closer to the golden ratio.
    // Let d = b + c, then the ratio d / c is closer to the golden ratio. 
    // Let e = c + d, then the ratio e / d is closer to the golden ratio.
    // If you continue this process, the result will trend towards the golden ratio.
    public static double GoldenRatio(double a, double b) {
        throw new Exception("Not Implemented");
    }
    
    // Give the nth Fibonacci number
    // Starting with 0, 1, 1, 2, ... a Fibonacci number is the sum of the previous two.
    public static int Fibonacci(int n) {
        throw new Exception("Not Implemented");
    }
    
    // Give the square root of a number
    // Using a binary search algorithm, search for the square root of a given number.
    // Do not use the built-in square root function.
    public static double SquareRoot(double n) {
        throw new Exception("Not Implemented");
    }
}
