public class Code {

    // Returns "Hello World!"
    public static String helloWorld() {
        throw new RuntimeException("Not Implemented");
    }

    // Take a single-spaced <sentence>, and capitalize every <n> word starting with <offset>.
    public static String capitalizeEveryNthWord(String sentence, Integer offset, Integer n) {
        throw new RuntimeException("Not Implemented");
    }

    // Determine if a number is prime
    public static Boolean isPrime(Integer n) {
        throw new RuntimeException("Not Implemented");
    }

    // Calculate the golden ratio.
    // Given two numbers a and b with a > b > 0, the ratio is b / a.
    // Let c = a + b, then the ratio c / b is closer to the golden ratio.
    // Let d = b + c, then the ratio d / c is closer to the golden ratio.
    // Let e = c + d, then the ratio e / d is closer to the golden ratio.
    // If you continue this process, the result will trend towards the golden ratio.
    public static Double goldenRatio(Double a, Double b) {
        throw new RuntimeException("Not Implemented");
    }

    // Give the nth Fibionacci number
    // Starting with 1 and 1, a Fibionacci number is the sum of the previous two.
    public static Integer fibionacci(Integer n) {
        throw new RuntimeException("Not Implemented");
    }

    // Give the square root of a number
    // Using a binary search algorithm, search for the square root of a given number.
    // Do not use the built-in square root function.
    public static Double squareRoot(Double n) {
        throw new RuntimeException("Not Implemented");
    }
}
