﻿module Code
// Returns "Hello World!"
let helloWorld() = 
    failwith "Not Implemented"
    
// Take a single-spaced <sentence>, and capitalize every <n>th word starting with <offset>.
let capitalizeEveryNthWord sentence offset count = 
    failwith "Not Implemented"

// Determine if a number is prime
let isPrime n = 
    failwith "Not Implemented"
    
// Calculate the golden ratio.
// Given two numbers a and b with a > b > 0, the ratio is b / a.
// Let c = a + b, then the ratio c / b is closer to the golden ratio.
// Let d = b + c, then the ratio d / c is closer to the golden ratio. 
// Let e = c + d, then the ratio e / d is closer to the golden ratio.
// If you continue this process, the result will trend towards the golden ratio.
let goldenRatio a b = 
    failwith "Not Implemented"

// Give the nth Fibonacci number
// Starting with 0, 1, 1, 2, ... a Fibonacci number is the sum of the previous two.
let fibonacci n =
    failwith "Not Implemented"

// Give the square root of a number
// Using a binary search algorithm, search for the square root of a given number.
// Do not use the built-in square root function.
let squareRoot n =
    failwith "Not Implemented"
    